package com.example.iptfinalproject.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.data.TaskRepository

class TaskOverdueFragment : Fragment() {

    private lateinit var tvBannerCount: TextView
    private lateinit var tvEmptyOverdue: TextView
    private lateinit var rvOverdueTasks: RecyclerView
    private lateinit var overdueAdapter: OverdueTaskAdapter

    private val repositoryListener = {
        refreshData()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_task_overdue, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(true)

        val btnOverdueBack = view.findViewById<ImageButton>(R.id.btnOverdueBack)
        tvBannerCount = view.findViewById(R.id.tvBannerCount)
        tvEmptyOverdue = view.findViewById(R.id.tvEmptyOverdue)
        rvOverdueTasks = view.findViewById(R.id.rvOverdueTasks)

        btnOverdueBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        overdueAdapter = OverdueTaskAdapter(
            tasks = emptyList(),
            onMarkDoneClick = { task ->
                TaskRepository.toggleTaskCompletion(task.id)
                Toast.makeText(requireContext(), "Marked task as done!", Toast.LENGTH_SHORT).show()
            },
            onRescheduleClick = { task ->
                TaskRepository.rescheduleOverdueTask(task.id)
                Toast.makeText(requireContext(), "Rescheduled task!", Toast.LENGTH_SHORT).show()
            }
        )

        rvOverdueTasks.layoutManager = LinearLayoutManager(requireContext())
        rvOverdueTasks.adapter = overdueAdapter

        TaskRepository.addListener(repositoryListener)
        refreshData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        TaskRepository.removeListener(repositoryListener)
    }

    private fun refreshData() {
        if (!isAdded) return

        val overdueList = TaskRepository.getOverdueTasks()
        tvBannerCount.text = "${overdueList.size} tasks overdue"

        if (overdueList.isEmpty()) {
            tvEmptyOverdue.visibility = View.VISIBLE
            rvOverdueTasks.visibility = View.GONE
        } else {
            tvEmptyOverdue.visibility = View.GONE
            rvOverdueTasks.visibility = View.VISIBLE
            overdueAdapter.updateTasks(overdueList)
        }
    }
}
