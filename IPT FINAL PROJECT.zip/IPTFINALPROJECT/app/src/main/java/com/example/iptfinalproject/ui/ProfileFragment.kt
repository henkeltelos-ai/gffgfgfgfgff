package com.example.iptfinalproject.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.fragment.app.Fragment
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.auth.AuthManager

class ProfileFragment : Fragment() {

    private var notificationsEnabled = true

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(true)
        (activity as? MainActivity)?.setSelectedNavTab(R.id.navProfile)

        val tvProfileUsername = view.findViewById<TextView>(R.id.tvProfileUsername)
        val tvProfileEmail = view.findViewById<TextView>(R.id.tvProfileEmail)
        val switchNotifications = view.findViewById<SwitchCompat>(R.id.switchNotifications)
        val btnLogout = view.findViewById<Button>(R.id.btnLogout)

        tvProfileUsername.text = AuthManager.getCurrentUsername()
        tvProfileEmail.text = AuthManager.getCurrentEmail()
        switchNotifications.isChecked = notificationsEnabled

        switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            notificationsEnabled = isChecked
        }

        btnLogout.setOnClickListener {
            val dialog = ConfirmLogoutDialog()
            dialog.show(parentFragmentManager, "ConfirmLogoutDialog")
        }
    }
}
