package com.example.iptfinalproject.data

import android.content.Context
import android.content.SharedPreferences
import com.example.iptfinalproject.auth.AuthManager
import com.google.firebase.database.FirebaseDatabase
import java.util.UUID

object TaskRepository {

    private val listeners = mutableListOf<() -> Unit>()
    private var prefs: SharedPreferences? = null

    // Map of user UID -> list of tasks (ensuring isolated account storage)
    private val userTasksMap = mutableMapOf<String, MutableList<Task>>()

    fun init(context: Context) {
        prefs = context.getSharedPreferences("edutrack_user_tasks", Context.MODE_PRIVATE)
        loadInitialTasksForUser(AuthManager.getCurrentUid())
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        listeners.forEach { it.invoke() }
    }

    private fun getUserTaskList(): MutableList<Task> {
        val uid = AuthManager.getCurrentUid()
        if (!userTasksMap.containsKey(uid)) {
            userTasksMap[uid] = createSampleTasksForUser(uid)
        }
        return userTasksMap[uid]!!
    }

    private fun createSampleTasksForUser(uid: String): MutableList<Task> {
        val sampleList = mutableListOf(
            Task(
                id = UUID.randomUUID().toString(),
                title = "Task name",
                subject = "Project DueDate",
                type = "Project",
                priority = Priority.HIGH,
                isCompleted = false,
                isOverdue = true,
                overdueText = "2 Days late",
                quiz = QuizGenerator.generateQuizForTask("Task name", "Project DueDate", "Project")
            ),
            Task(
                id = UUID.randomUUID().toString(),
                title = "Task name",
                subject = "Subject",
                type = "Assignment",
                priority = Priority.HIGH,
                isCompleted = false,
                quiz = QuizGenerator.generateQuizForTask("Task name", "Subject", "Assignment")
            ),
            Task(
                id = UUID.randomUUID().toString(),
                title = "Task name",
                subject = "Subject",
                type = "Assignment",
                priority = Priority.MEDIUM,
                isCompleted = false,
                quiz = QuizGenerator.generateQuizForTask("Task name", "Subject", "Assignment")
            ),
            Task(
                id = UUID.randomUUID().toString(),
                title = "Task name",
                subject = "Subject",
                type = "Exam",
                priority = Priority.LOW,
                isCompleted = false,
                quiz = QuizGenerator.generateQuizForTask("Task name", "Subject", "Exam")
            ),
            Task(
                id = UUID.randomUUID().toString(),
                title = "Rizal reporting",
                subject = "History",
                type = "Assignment",
                priority = Priority.MEDIUM,
                isCompleted = true,
                quiz = QuizGenerator.generateQuizForTask("Rizal reporting", "History", "Assignment")
            ),
            Task(
                id = UUID.randomUUID().toString(),
                title = "Math Calculus Quiz",
                subject = "Mathematics",
                type = "Exam",
                priority = Priority.LOW,
                isCompleted = true,
                quiz = QuizGenerator.generateQuizForTask("Math Calculus Quiz", "Mathematics", "Exam")
            )
        )
        return sampleList
    }

    private fun loadInitialTasksForUser(uid: String) {
        if (!userTasksMap.containsKey(uid)) {
            userTasksMap[uid] = createSampleTasksForUser(uid)
        }
    }

    fun getTasks(): List<Task> = getUserTaskList().toList()

    fun getPendingTasks(): List<Task> = getUserTaskList().filter { !it.isCompleted }

    fun getCompletedTasks(): List<Task> = getUserTaskList().filter { it.isCompleted }

    fun getOverdueTasks(): List<Task> = getUserTaskList().filter { it.isOverdue && !it.isCompleted }

    fun getUpcomingTasksCount(): Int = getUserTaskList().count { !it.isCompleted && !it.isOverdue }

    fun addTask(task: Task) {
        if (task.quiz == null) {
            task.quiz = QuizGenerator.generateQuizForTask(task.title, task.subject, task.type)
        }
        getUserTaskList().add(0, task)
        syncWithFirebase(task)
        notifyListeners()
    }

    fun answerTaskQuiz(taskId: String, selectedOption: Int): Boolean {
        val task = getUserTaskList().find { it.id == taskId } ?: return false
        val quiz = task.quiz ?: return false

        quiz.selectedOption = selectedOption
        val isCorrect = (selectedOption == quiz.correctOption)
        quiz.isAnsweredCorrectly = isCorrect

        notifyListeners()
        return isCorrect
    }

    fun toggleTaskCompletion(taskId: String) {
        val task = getUserTaskList().find { it.id == taskId }
        if (task != null) {
            task.isCompleted = !task.isCompleted
            if (task.isCompleted) {
                task.isOverdue = false
            }
            syncWithFirebase(task)
            notifyListeners()
        }
    }

    fun rescheduleOverdueTask(taskId: String) {
        val task = getUserTaskList().find { it.id == taskId }
        if (task != null) {
            task.isOverdue = false
            task.overdueText = ""
            syncWithFirebase(task)
            notifyListeners()
        }
    }

    private fun syncWithFirebase(task: Task) {
        try {
            val uid = AuthManager.getCurrentUid()
            val db = FirebaseDatabase.getInstance().getReference("users").child(uid).child("tasks")
            val taskMap = mapOf(
                "id" to task.id,
                "title" to task.title,
                "subject" to task.subject,
                "type" to task.type,
                "priority" to task.priority.name,
                "isCompleted" to task.isCompleted,
                "isOverdue" to task.isOverdue
            )
            db.child(task.id).setValue(taskMap)
        } catch (e: Exception) {
            // Ignore if Firebase console offline
        }
    }
}
