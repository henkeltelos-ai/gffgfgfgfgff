package com.example.iptfinalproject.ui

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.example.iptfinalproject.R
import com.example.iptfinalproject.data.Task
import com.example.iptfinalproject.data.TaskRepository

class DialogTaskQuiz(private val task: Task) : DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return inflater.inflate(R.layout.dialog_task_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvHeader = view.findViewById<TextView>(R.id.tvQuizHeader)
        val tvQuestion = view.findViewById<TextView>(R.id.tvQuizQuestion)
        val rgOptions = view.findViewById<RadioGroup>(R.id.rgQuizOptions)
        val rbA = view.findViewById<RadioButton>(R.id.rbOptionA)
        val rbB = view.findViewById<RadioButton>(R.id.rbOptionB)
        val rbC = view.findViewById<RadioButton>(R.id.rbOptionC)
        val rbD = view.findViewById<RadioButton>(R.id.rbOptionD)
        val tvFeedback = view.findViewById<TextView>(R.id.tvQuizFeedback)
        val btnClose = view.findViewById<Button>(R.id.btnCloseQuiz)
        val btnSubmit = view.findViewById<Button>(R.id.btnSubmitAnswer)

        val quiz = task.quiz ?: return

        tvHeader.text = "Q&A Quiz: ${task.title}"
        tvQuestion.text = quiz.question
        rbA.text = quiz.optionA
        rbB.text = quiz.optionB
        rbC.text = quiz.optionC
        rbD.text = quiz.optionD

        if (quiz.selectedOption > 0) {
            when (quiz.selectedOption) {
                1 -> rbA.isChecked = true
                2 -> rbB.isChecked = true
                3 -> rbC.isChecked = true
                4 -> rbD.isChecked = true
            }
            if (quiz.isAnsweredCorrectly) {
                tvFeedback.visibility = View.VISIBLE
                tvFeedback.text = "Correct! +10 Points"
                tvFeedback.setTextColor(ContextCompat.getColor(requireContext(), R.color.badge_low_text))
            }
        }

        btnClose.setOnClickListener { dismiss() }

        btnSubmit.setOnClickListener {
            val selectedId = rgOptions.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(requireContext(), "Please select an answer (A, B, C, or D)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val optionChoice = when (selectedId) {
                R.id.rbOptionA -> 1
                R.id.rbOptionB -> 2
                R.id.rbOptionC -> 3
                R.id.rbOptionD -> 4
                else -> 1
            }

            val isCorrect = TaskRepository.answerTaskQuiz(task.id, optionChoice)
            tvFeedback.visibility = View.VISIBLE

            if (isCorrect) {
                tvFeedback.text = "Correct! Excellent job! (+10 Mastery Points)"
                tvFeedback.setTextColor(ContextCompat.getColor(requireContext(), R.color.badge_low_text))
            } else {
                tvFeedback.text = "Incorrect answer. Try again!"
                tvFeedback.setTextColor(ContextCompat.getColor(requireContext(), R.color.badge_high_text))
            }
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}
