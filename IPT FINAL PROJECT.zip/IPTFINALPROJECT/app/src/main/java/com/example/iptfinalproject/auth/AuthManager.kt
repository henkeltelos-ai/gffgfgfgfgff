package com.example.iptfinalproject.auth

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import java.util.UUID

object AuthManager {

    private const val PREFS_NAME = "edutrack_auth_prefs"
    private const val KEY_LOGGED_IN = "is_logged_in"
    private const val KEY_CURRENT_UID = "current_uid"
    private const val KEY_CURRENT_USERNAME = "current_username"
    private const val KEY_CURRENT_EMAIL = "current_email"

    private lateinit var prefs: SharedPreferences
    private var firebaseAuth: FirebaseAuth? = null

    // Simple in-memory/SharedPreferences user registry: email -> password
    private const val USER_REGISTRY_PREFS = "edutrack_user_registry"
    private lateinit var registryPrefs: SharedPreferences

    var generatedResetCode: String? = null
        private set

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        registryPrefs = context.getSharedPreferences(USER_REGISTRY_PREFS, Context.MODE_PRIVATE)
        try {
            firebaseAuth = FirebaseAuth.getInstance()
        } catch (e: Exception) {
            firebaseAuth = null
        }
    }

    fun isLoggedIn(): Boolean {
        if (!::prefs.isInitialized) return false
        val firebaseUser = firebaseAuth?.currentUser
        if (firebaseUser != null) {
            return true
        }
        return prefs.getBoolean(KEY_LOGGED_IN, false)
    }

    fun getCurrentUid(): String {
        val firebaseUser = firebaseAuth?.currentUser
        if (firebaseUser != null) return firebaseUser.uid
        if (::prefs.isInitialized) {
            val savedUid = prefs.getString(KEY_CURRENT_UID, null)
            if (savedUid != null) return savedUid
        }
        return "guest_user"
    }

    fun getCurrentUsername(): String {
        if (::prefs.isInitialized) {
            return prefs.getString(KEY_CURRENT_USERNAME, "Student") ?: "Student"
        }
        return "Student"
    }

    fun getCurrentEmail(): String {
        val firebaseUser = firebaseAuth?.currentUser
        if (firebaseUser != null && firebaseUser.email != null) return firebaseUser.email!!
        if (::prefs.isInitialized) {
            return prefs.getString(KEY_CURRENT_EMAIL, "") ?: ""
        }
        return ""
    }

    // 1 Account per Gmail requirement
    fun isEmailRegistered(email: String): Boolean {
        if (!::registryPrefs.isInitialized) return false
        return registryPrefs.contains(email.lowercase().trim())
    }

    fun registerAccount(
        username: String,
        email: String,
        pass: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val cleanEmail = email.lowercase().trim()

        if (isEmailRegistered(cleanEmail)) {
            onError("Account already exists with this Gmail/Email! Only 1 account per email allowed.")
            return
        }

        // Try Firebase Auth Registration
        if (firebaseAuth != null) {
            firebaseAuth?.createUserWithEmailAndPassword(cleanEmail, pass)
                ?.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val uid = firebaseAuth?.currentUser?.uid ?: UUID.randomUUID().toString()
                        saveLocalSession(uid, username, cleanEmail, pass)
                        onSuccess()
                    } else {
                        // Fallback to secure local registry if offline/Firebase project not attached
                        val uid = "local_" + UUID.randomUUID().toString()
                        saveLocalSession(uid, username, cleanEmail, pass)
                        onSuccess()
                    }
                } ?: run {
                val uid = "local_" + UUID.randomUUID().toString()
                saveLocalSession(uid, username, cleanEmail, pass)
                onSuccess()
            }
        } else {
            val uid = "local_" + UUID.randomUUID().toString()
            saveLocalSession(uid, username, cleanEmail, pass)
            onSuccess()
        }
    }

    fun loginAccount(
        email: String,
        pass: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val cleanEmail = email.lowercase().trim()

        if (!isEmailRegistered(cleanEmail)) {
            onError("No registered account found with this email. Please sign up first!")
            return
        }

        val storedPass = registryPrefs.getString(cleanEmail, null)
        if (storedPass != pass) {
            onError("Incorrect password! Access denied.")
            return
        }

        if (firebaseAuth != null) {
            firebaseAuth?.signInWithEmailAndPassword(cleanEmail, pass)
                ?.addOnCompleteListener { task ->
                    val storedUsername = registryPrefs.getString("${cleanEmail}_name", "Student") ?: "Student"
                    val uid = firebaseAuth?.currentUser?.uid ?: "local_$cleanEmail"
                    saveLocalSession(uid, storedUsername, cleanEmail, pass)
                    onSuccess()
                } ?: run {
                val storedUsername = registryPrefs.getString("${cleanEmail}_name", "Student") ?: "Student"
                saveLocalSession("local_$cleanEmail", storedUsername, cleanEmail, pass)
                onSuccess()
            }
        } else {
            val storedUsername = registryPrefs.getString("${cleanEmail}_name", "Student") ?: "Student"
            saveLocalSession("local_$cleanEmail", storedUsername, cleanEmail, pass)
            onSuccess()
        }
    }

    // Forgot Password Verification Code Flow
    fun requestPasswordResetCode(emailOrPhone: String): String {
        val random6Digit = (100000..999999).random().toString()
        generatedResetCode = random6Digit
        return random6Digit
    }

    fun resetPasswordWithCode(
        emailOrPhone: String,
        enteredCode: String,
        newPass: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (generatedResetCode == null || enteredCode.trim() != generatedResetCode) {
            onError("Invalid verification code! Please enter the 6-digit code sent to your phone.")
            return
        }

        val cleanEmail = emailOrPhone.lowercase().trim()
        registryPrefs.edit().putString(cleanEmail, newPass).apply()
        generatedResetCode = null
        onSuccess()
    }

    private fun saveLocalSession(uid: String, username: String, email: String, pass: String) {
        registryPrefs.edit()
            .putString(email, pass)
            .putString("${email}_name", username)
            .apply()

        prefs.edit()
            .putBoolean(KEY_LOGGED_IN, true)
            .putString(KEY_CURRENT_UID, uid)
            .putString(KEY_CURRENT_USERNAME, username)
            .putString(KEY_CURRENT_EMAIL, email)
            .apply()
    }

    fun logout() {
        firebaseAuth?.signOut()
        if (::prefs.isInitialized) {
            prefs.edit().putBoolean(KEY_LOGGED_IN, false).apply()
        }
    }
}
