package com.example.iptfinalproject.ui

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.iptfinalproject.R
import com.example.iptfinalproject.data.Priority
import com.example.iptfinalproject.data.Task

class TaskAdapter(
    private var tasks: List<Task>,
    private val onTaskCheckToggle: (Task) -> Unit,
    private val onTaskItemClick: ((Task) -> Unit)? = null
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCheck: ImageView = itemView.findViewById(R.id.ivTaskCheck)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTaskTitle)
        val tvSubject: TextView = itemView.findViewById(R.id.tvTaskSubject)
        val tvPriorityBadge: TextView = itemView.findViewById(R.id.tvPriorityBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.tvTitle.text = task.title

        val quizInfo = if (task.quiz?.isAnsweredCorrectly == true) " • Quiz Passed ✓" else " • Tap to answer Q&A"
        holder.tvSubject.text = "${task.subject}$quizInfo"

        if (task.isCompleted) {
            holder.ivCheck.setImageResource(R.drawable.ic_check_circle)
            holder.tvTitle.paintFlags = holder.tvTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            holder.tvTitle.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_secondary))
        } else {
            holder.ivCheck.setImageResource(R.drawable.ic_unchecked_circle)
            holder.tvTitle.paintFlags = holder.tvTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            holder.tvTitle.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_primary))
        }

        // Priority Badge setup
        when (task.priority) {
            Priority.HIGH -> {
                holder.tvPriorityBadge.text = "High"
                holder.tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_high)
                holder.tvPriorityBadge.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.badge_high_text))
            }
            Priority.MEDIUM -> {
                holder.tvPriorityBadge.text = "Medium"
                holder.tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_medium)
                holder.tvPriorityBadge.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.badge_medium_text))
            }
            Priority.LOW -> {
                holder.tvPriorityBadge.text = "Low"
                holder.tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_low)
                holder.tvPriorityBadge.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.badge_low_text))
            }
        }

        holder.ivCheck.setOnClickListener {
            onTaskCheckToggle(task)
        }

        holder.itemView.setOnClickListener {
            if (onTaskItemClick != null) {
                onTaskItemClick.invoke(task)
            } else {
                val activity = holder.itemView.context as? FragmentActivity
                if (activity != null && task.quiz != null) {
                    val dialog = DialogTaskQuiz(task)
                    dialog.show(activity.supportFragmentManager, "DialogTaskQuiz")
                }
            }
        }
    }

    override fun getItemCount(): Int = tasks.size

    fun updateTasks(newTasks: List<Task>) {
        tasks = newTasks
        notifyDataSetChanged()
    }
}
