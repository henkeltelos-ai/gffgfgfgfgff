package com.example.iptfinalproject.data

enum class Priority {
    HIGH, MEDIUM, LOW
}

data class Task(
    val id: String,
    val title: String,
    val subject: String,
    val type: String = "Assignment", // Assignment, Project, Exam
    val priority: Priority = Priority.MEDIUM,
    val deadlineDate: String = "",
    val deadlineTime: String = "",
    val reminder: String = "",
    var isCompleted: Boolean = false,
    var isOverdue: Boolean = false,
    var overdueText: String = "",
    var quiz: TaskQuiz? = null
)
