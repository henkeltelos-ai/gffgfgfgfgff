package com.example.iptfinalproject.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.auth.AuthManager

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(false)

        val etEmail = view.findViewById<EditText>(R.id.etEmail)
        val etPassword = view.findViewById<EditText>(R.id.etPassword)
        val btnLogin = view.findViewById<Button>(R.id.btnLogin)
        val btnForgotPassword = view.findViewById<TextView>(R.id.btnForgotPassword)
        val btnGoToSignup = view.findViewById<TextView>(R.id.btnGoToSignup)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty()) {
                etEmail.error = "Email is required"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                etPassword.error = "Password is required"
                return@setOnClickListener
            }

            AuthManager.loginAccount(
                email = email,
                pass = password,
                onSuccess = {
                    Toast.makeText(requireContext(), "Welcome back, ${AuthManager.getCurrentUsername()}!", Toast.LENGTH_SHORT).show()
                    (activity as? MainActivity)?.navigateToHome()
                },
                onError = { errorMsg ->
                    Toast.makeText(requireContext(), errorMsg, Toast.LENGTH_LONG).show()
                }
            )
        }

        btnForgotPassword.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(ForgotPasswordFragment())
        }

        btnGoToSignup.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(SignupFragment())
        }
    }
}
