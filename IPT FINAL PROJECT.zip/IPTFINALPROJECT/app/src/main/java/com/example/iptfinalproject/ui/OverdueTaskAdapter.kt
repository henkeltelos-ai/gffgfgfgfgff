package com.example.iptfinalproject.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.iptfinalproject.R
import com.example.iptfinalproject.data.Priority
import com.example.iptfinalproject.data.Task

class OverdueTaskAdapter(
    private var tasks: List<Task>,
    private val onMarkDoneClick: (Task) -> Unit,
    private val onRescheduleClick: (Task) -> Unit
) : RecyclerView.Adapter<OverdueTaskAdapter.OverdueViewHolder>() {

    class OverdueViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tvOverdueTitle)
        val tvSubject: TextView = itemView.findViewById(R.id.tvOverdueSubject)
        val tvPriorityBadge: TextView = itemView.findViewById(R.id.tvOverduePriority)
        val tvDaysLate: TextView = itemView.findViewById(R.id.tvDaysLate)
        val btnMarkDone: Button = itemView.findViewById(R.id.btnMarkDone)
        val btnReschedule: Button = itemView.findViewById(R.id.btnReschedule)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OverdueViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_overdue_task, parent, false)
        return OverdueViewHolder(view)
    }

    override fun onBindViewHolder(holder: OverdueViewHolder, position: Int) {
        val task = tasks[position]
        holder.tvTitle.text = task.title
        holder.tvSubject.text = "${task.subject} ${task.type} ${task.deadlineDate}".trim()
        holder.tvDaysLate.text = if (task.overdueText.isNotEmpty()) task.overdueText else "1 Day late"

        when (task.priority) {
            Priority.HIGH -> {
                holder.tvPriorityBadge.text = "High"
                holder.tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_high)
                holder.tvPriorityBadge.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.badge_high_text))
            }
            Priority.MEDIUM -> {
                holder.tvPriorityBadge.text = "Medium"
                holder.tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_medium)
                holder.tvPriorityBadge.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.badge_medium_text))
            }
            Priority.LOW -> {
                holder.tvPriorityBadge.text = "Low"
                holder.tvPriorityBadge.setBackgroundResource(R.drawable.bg_badge_low)
                holder.tvPriorityBadge.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.badge_low_text))
            }
        }

        holder.btnMarkDone.setOnClickListener {
            onMarkDoneClick(task)
        }

        holder.btnReschedule.setOnClickListener {
            onRescheduleClick(task)
        }
    }

    override fun getItemCount(): Int = tasks.size

    fun updateTasks(newTasks: List<Task>) {
        tasks = newTasks
        notifyDataSetChanged()
    }
}
