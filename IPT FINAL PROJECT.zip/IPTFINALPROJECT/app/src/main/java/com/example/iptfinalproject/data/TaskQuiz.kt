package com.example.iptfinalproject.data

data class TaskQuiz(
    val question: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: Int, // 1 for A, 2 for B, 3 for C, 4 for D
    var selectedOption: Int = 0, // 0 = unselected
    var isAnsweredCorrectly: Boolean = false
)
