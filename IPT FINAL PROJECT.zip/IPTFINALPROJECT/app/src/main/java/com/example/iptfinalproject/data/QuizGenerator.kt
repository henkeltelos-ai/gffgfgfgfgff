package com.example.iptfinalproject.data

object QuizGenerator {

    fun generateQuizForTask(title: String, subject: String, type: String): TaskQuiz {
        val lowerSubject = subject.lowercase()
        val lowerTitle = title.lowercase()

        return when {
            lowerSubject.contains("history") || lowerTitle.contains("rizal") || lowerSubject.contains("social") -> {
                TaskQuiz(
                    question = "Q&A for '$title': What is the primary milestone of this $type?",
                    optionA = "A) Analyze historical documents & key figures",
                    optionB = "B) Solve quadratic equations",
                    optionC = "C) Execute physical fitness routine",
                    optionD = "D) Write a C++ program",
                    correctOption = 1
                )
            }
            lowerSubject.contains("math") || lowerSubject.contains("calculus") || lowerTitle.contains("math") -> {
                TaskQuiz(
                    question = "Q&A for '$title': What is the derivative of x² with respect to x?",
                    optionA = "A) x",
                    optionB = "B) 2x",
                    optionC = "C) x² / 2",
                    optionD = "D) 2x + C",
                    correctOption = 2
                )
            }
            lowerSubject.contains("science") || lowerSubject.contains("physics") || lowerSubject.contains("chem") -> {
                TaskQuiz(
                    question = "Q&A for '$title': What key principle is evaluated in this $type?",
                    optionA = "A) Newton's laws & chemical formulas",
                    optionB = "B) Literary character analysis",
                    optionC = "C) World geography mapping",
                    optionD = "D) Musical staff notation",
                    correctOption = 1
                )
            }
            else -> {
                TaskQuiz(
                    question = "Q&A for '$title': What is the main objective of this $subject $type?",
                    optionA = "A) Review key concepts & master core topic",
                    optionB = "B) Skip all instructions",
                    optionC = "C) Submit blank assignment",
                    optionD = "D) None of the above",
                    correctOption = 1
                )
            }
        }
    }
}
