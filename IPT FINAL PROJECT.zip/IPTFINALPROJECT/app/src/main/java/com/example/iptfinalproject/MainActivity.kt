package com.example.iptfinalproject

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.iptfinalproject.auth.AuthManager
import com.example.iptfinalproject.data.TaskRepository
import com.example.iptfinalproject.ui.HomeFragment
import com.example.iptfinalproject.ui.LoginFragment
import com.example.iptfinalproject.ui.MyTasksFragment
import com.example.iptfinalproject.ui.ProfileFragment

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNavCard: CardView
    private lateinit var ivNavHome: ImageView
    private lateinit var ivNavTasks: ImageView
    private lateinit var ivNavProfile: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        AuthManager.init(applicationContext)
        TaskRepository.init(applicationContext)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        bottomNavCard = findViewById(R.id.bottomNavCard)
        ivNavHome = findViewById(R.id.ivNavHome)
        ivNavTasks = findViewById(R.id.ivNavTasks)
        ivNavProfile = findViewById(R.id.ivNavProfile)

        val navHome = findViewById<FrameLayout>(R.id.navHome)
        val navTasks = findViewById<FrameLayout>(R.id.navTasks)
        val navProfile = findViewById<FrameLayout>(R.id.navProfile)

        navHome.setOnClickListener {
            if (AuthManager.isLoggedIn()) navigateToHome() else forceLogin()
        }
        navTasks.setOnClickListener {
            if (AuthManager.isLoggedIn()) navigateToMyTasks() else forceLogin()
        }
        navProfile.setOnClickListener {
            if (AuthManager.isLoggedIn()) navigateToProfile() else forceLogin()
        }

        if (savedInstanceState == null) {
            if (AuthManager.isLoggedIn()) {
                navigateToHome()
            } else {
                forceLogin()
            }
        }
    }

    fun forceLogin() {
        setBottomNavVisible(false)
        loadFragment(LoginFragment())
    }

    fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    fun navigateToHome() {
        if (!AuthManager.isLoggedIn()) {
            forceLogin()
            return
        }
        setSelectedNavTab(R.id.navHome)
        loadFragment(HomeFragment())
    }

    fun navigateToMyTasks() {
        if (!AuthManager.isLoggedIn()) {
            forceLogin()
            return
        }
        setSelectedNavTab(R.id.navTasks)
        loadFragment(MyTasksFragment())
    }

    fun navigateToProfile() {
        if (!AuthManager.isLoggedIn()) {
            forceLogin()
            return
        }
        setSelectedNavTab(R.id.navProfile)
        loadFragment(ProfileFragment())
    }

    fun setBottomNavVisible(visible: Boolean) {
        if (!AuthManager.isLoggedIn()) {
            bottomNavCard.visibility = View.GONE
            return
        }
        bottomNavCard.visibility = if (visible) View.VISIBLE else View.GONE
    }

    fun setSelectedNavTab(navId: Int) {
        val activeColor = ContextCompat.getColor(this, R.color.primary_blue)
        val inactiveColor = ContextCompat.getColor(this, R.color.text_secondary)

        ivNavHome.setColorFilter(if (navId == R.id.navHome) activeColor else inactiveColor)
        ivNavTasks.setColorFilter(if (navId == R.id.navTasks) activeColor else inactiveColor)
        ivNavProfile.setColorFilter(if (navId == R.id.navProfile) activeColor else inactiveColor)
    }
}
