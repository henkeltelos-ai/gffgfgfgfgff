package com.example.iptfinalproject.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.auth.AuthManager
import com.example.iptfinalproject.data.TaskRepository

class HomeFragment : Fragment() {

    private lateinit var tvHeaderGreeting: TextView
    private lateinit var tvProgressPercentage: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvCountPending: TextView
    private lateinit var tvCountCompleted: TextView
    private lateinit var tvCountUpcoming: TextView
    private lateinit var cardOverdueBanner: CardView
    private lateinit var tvOverdueBannerTitle: TextView
    private lateinit var rvDueSoon: RecyclerView
    private lateinit var taskAdapter: TaskAdapter

    private val repositoryListener = {
        refreshData()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(true)
        (activity as? MainActivity)?.setSelectedNavTab(R.id.navHome)

        tvHeaderGreeting = view.findViewById(R.id.tvHeaderGreeting)
        tvProgressPercentage = view.findViewById(R.id.tvProgressPercentage)
        progressBar = view.findViewById(R.id.progressBar)
        tvCountPending = view.findViewById(R.id.tvCountPending)
        tvCountCompleted = view.findViewById(R.id.tvCountCompleted)
        tvCountUpcoming = view.findViewById(R.id.tvCountUpcoming)
        cardOverdueBanner = view.findViewById(R.id.cardOverdueBanner)
        tvOverdueBannerTitle = view.findViewById(R.id.tvOverdueBannerTitle)
        rvDueSoon = view.findViewById(R.id.rvDueSoon)

        val btnHeaderProfile = view.findViewById<ImageView>(R.id.btnHeaderProfile)
        val btnSeeAll = view.findViewById<TextView>(R.id.btnSeeAll)

        btnHeaderProfile.setOnClickListener {
            (activity as? MainActivity)?.navigateToProfile()
        }

        btnSeeAll.setOnClickListener {
            (activity as? MainActivity)?.navigateToMyTasks()
        }

        cardOverdueBanner.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(TaskOverdueFragment())
        }

        taskAdapter = TaskAdapter(
            tasks = emptyList(),
            onTaskCheckToggle = { task ->
                TaskRepository.toggleTaskCompletion(task.id)
            },
            onTaskItemClick = { task ->
                if (task.quiz != null) {
                    val dialog = DialogTaskQuiz(task)
                    dialog.show(childFragmentManager, "DialogTaskQuiz")
                }
            }
        )

        rvDueSoon.layoutManager = LinearLayoutManager(requireContext())
        rvDueSoon.adapter = taskAdapter

        TaskRepository.addListener(repositoryListener)
        refreshData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        TaskRepository.removeListener(repositoryListener)
    }

    private fun refreshData() {
        if (!isAdded) return

        tvHeaderGreeting.text = "Hi, ${AuthManager.getCurrentUsername()}"

        val allTasks = TaskRepository.getTasks()
        val pendingTasks = TaskRepository.getPendingTasks()
        val completedTasks = TaskRepository.getCompletedTasks()
        val overdueTasks = TaskRepository.getOverdueTasks()
        val upcomingCount = TaskRepository.getUpcomingTasksCount()

        val totalCount = allTasks.size
        val completedCount = completedTasks.size
        val pendingCount = pendingTasks.size

        val percentage = if (totalCount > 0) (completedCount * 100) / totalCount else 0
        tvProgressPercentage.text = "$percentage% done"
        progressBar.progress = percentage

        tvCountPending.text = pendingCount.toString()
        tvCountCompleted.text = completedCount.toString()
        tvCountUpcoming.text = upcomingCount.toString()

        if (overdueTasks.isNotEmpty()) {
            cardOverdueBanner.visibility = View.VISIBLE
            tvOverdueBannerTitle.text = "${overdueTasks.size} tasks overdue"
        } else {
            cardOverdueBanner.visibility = View.GONE
        }

        taskAdapter.updateTasks(pendingTasks)
    }
}
