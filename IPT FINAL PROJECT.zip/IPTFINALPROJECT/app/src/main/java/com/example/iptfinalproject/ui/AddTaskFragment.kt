package com.example.iptfinalproject.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.data.Priority
import com.example.iptfinalproject.data.Task
import com.example.iptfinalproject.data.TaskRepository
import java.util.Calendar
import java.util.UUID

class AddTaskFragment : Fragment() {

    private var selectedType = "Assignment"
    private var selectedPriority = Priority.MEDIUM
    private var selectedDate = ""
    private var selectedTime = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_add_task, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(true)

        val btnClose = view.findViewById<ImageView>(R.id.btnCloseAddTask)
        val etTitle = view.findViewById<EditText>(R.id.etTaskTitle)
        val etSubject = view.findViewById<EditText>(R.id.etTaskSubject)
        val etReminder = view.findViewById<EditText>(R.id.etReminder)
        val tvSelectDate = view.findViewById<TextView>(R.id.tvSelectDate)
        val tvSelectTime = view.findViewById<TextView>(R.id.tvSelectTime)
        val btnSaveTask = view.findViewById<Button>(R.id.btnSaveTask)

        val chipAssignment = view.findViewById<TextView>(R.id.chipTypeAssignment)
        val chipProject = view.findViewById<TextView>(R.id.chipTypeProject)
        val chipExam = view.findViewById<TextView>(R.id.chipTypeExam)

        val chipHigh = view.findViewById<TextView>(R.id.chipPriorityHigh)
        val chipMedium = view.findViewById<TextView>(R.id.chipPriorityMedium)
        val chipLow = view.findViewById<TextView>(R.id.chipPriorityLow)

        btnClose.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        // Type selection handling
        fun updateTypeSelection(type: String) {
            selectedType = type
            fun applyTypeChipStyle(chip: TextView, isSelected: Boolean) {
                if (isSelected) {
                    chip.setBackgroundResource(R.drawable.bg_tab_selected)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                } else {
                    chip.setBackgroundResource(R.drawable.bg_tab_unselected)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
                }
            }
            applyTypeChipStyle(chipAssignment, type == "Assignment")
            applyTypeChipStyle(chipProject, type == "Project")
            applyTypeChipStyle(chipExam, type == "Exam")
        }

        chipAssignment.setOnClickListener { updateTypeSelection("Assignment") }
        chipProject.setOnClickListener { updateTypeSelection("Project") }
        chipExam.setOnClickListener { updateTypeSelection("Exam") }

        // Priority selection handling
        fun updatePrioritySelection(priority: Priority) {
            selectedPriority = priority
            fun applyPriorityChipStyle(chip: TextView, isSelected: Boolean) {
                if (isSelected) {
                    chip.setBackgroundResource(R.drawable.bg_tab_selected)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                } else {
                    chip.setBackgroundResource(R.drawable.bg_tab_unselected)
                    chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
                }
            }
            applyPriorityChipStyle(chipHigh, priority == Priority.HIGH)
            applyPriorityChipStyle(chipMedium, priority == Priority.MEDIUM)
            applyPriorityChipStyle(chipLow, priority == Priority.LOW)
        }

        chipHigh.setOnClickListener { updatePrioritySelection(Priority.HIGH) }
        chipMedium.setOnClickListener { updatePrioritySelection(Priority.MEDIUM) }
        chipLow.setOnClickListener { updatePrioritySelection(Priority.LOW) }

        // Date Picker
        tvSelectDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePickerDialog = DatePickerDialog(
                requireContext(),
                { _, year, month, dayOfMonth ->
                    selectedDate = "${month + 1}/$dayOfMonth/$year"
                    tvSelectDate.text = selectedDate
                    tvSelectDate.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePickerDialog.show()
        }

        // Time Picker
        tvSelectTime.setOnClickListener {
            val calendar = Calendar.getInstance()
            val timePickerDialog = TimePickerDialog(
                requireContext(),
                { _, hourOfDay, minute ->
                    val amPm = if (hourOfDay >= 12) "PM" else "AM"
                    val hour = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                    selectedTime = String.format("%02d:%02d %s", hour, minute, amPm)
                    tvSelectTime.text = selectedTime
                    tvSelectTime.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
            )
            timePickerDialog.show()
        }

        // Save Task
        btnSaveTask.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val subject = etSubject.text.toString().trim()
            val reminder = etReminder.text.toString().trim()

            if (title.isEmpty()) {
                etTitle.error = "Title is required"
                return@setOnClickListener
            }
            if (subject.isEmpty()) {
                etSubject.error = "Subject is required"
                return@setOnClickListener
            }

            val newTask = Task(
                id = UUID.randomUUID().toString(),
                title = title,
                subject = subject,
                type = selectedType,
                priority = selectedPriority,
                deadlineDate = selectedDate,
                deadlineTime = selectedTime,
                reminder = reminder,
                isCompleted = false
            )

            TaskRepository.addTask(newTask)
            Toast.makeText(requireContext(), "Task added successfully!", Toast.LENGTH_SHORT).show()
            (activity as? MainActivity)?.navigateToMyTasks()
        }
    }
}
