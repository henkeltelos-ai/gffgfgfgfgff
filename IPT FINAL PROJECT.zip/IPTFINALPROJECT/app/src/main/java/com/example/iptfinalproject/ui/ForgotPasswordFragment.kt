package com.example.iptfinalproject.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.auth.AuthManager

class ForgotPasswordFragment : Fragment() {

    private var isCodeSent = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_forgot_password, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(false)

        val btnBack = view.findViewById<ImageButton>(R.id.btnBack)
        val etEmail = view.findViewById<EditText>(R.id.etEmail)
        val tvCodeDisplayBanner = view.findViewById<TextView>(R.id.tvCodeDisplayBanner)
        val layoutStep2 = view.findViewById<LinearLayout>(R.id.layoutStep2)
        val etVerificationCode = view.findViewById<EditText>(R.id.etVerificationCode)
        val etNewPassword = view.findViewById<EditText>(R.id.etNewPassword)
        val btnSendReset = view.findViewById<Button>(R.id.btnSendReset)
        val btnBackToLogin = view.findViewById<TextView>(R.id.btnBackToLogin)

        btnBack.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(LoginFragment())
        }

        btnSendReset.setOnClickListener {
            val emailOrPhone = etEmail.text.toString().trim()
            if (emailOrPhone.isEmpty()) {
                etEmail.error = "Email or Phone is required"
                return@setOnClickListener
            }

            if (!isCodeSent) {
                // Step 1: Send verification code
                val code = AuthManager.requestPasswordResetCode(emailOrPhone)
                isCodeSent = true

                tvCodeDisplayBanner.visibility = View.VISIBLE
                tvCodeDisplayBanner.text = "Verification Security Code Sent to $emailOrPhone:\n[ $code ]"

                layoutStep2.visibility = View.VISIBLE
                btnSendReset.text = "Verify Code & Reset Password"
                Toast.makeText(requireContext(), "Verification Code Generated: $code", Toast.LENGTH_LONG).show()
            } else {
                // Step 2: Verify Code and Reset Password
                val enteredCode = etVerificationCode.text.toString().trim()
                val newPass = etNewPassword.text.toString().trim()

                if (enteredCode.length != 6) {
                    etVerificationCode.error = "Enter 6-digit code"
                    return@setOnClickListener
                }
                if (newPass.length < 6) {
                    etNewPassword.error = "Password must be at least 6 characters"
                    return@setOnClickListener
                }

                AuthManager.resetPasswordWithCode(
                    emailOrPhone = emailOrPhone,
                    enteredCode = enteredCode,
                    newPass = newPass,
                    onSuccess = {
                        Toast.makeText(requireContext(), "Password reset successfully! Please log in with your new password.", Toast.LENGTH_LONG).show()
                        (activity as? MainActivity)?.loadFragment(LoginFragment())
                    },
                    onError = { errorMsg ->
                        Toast.makeText(requireContext(), errorMsg, Toast.LENGTH_LONG).show()
                    }
                )
            }
        }

        btnBackToLogin.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(LoginFragment())
        }
    }
}
