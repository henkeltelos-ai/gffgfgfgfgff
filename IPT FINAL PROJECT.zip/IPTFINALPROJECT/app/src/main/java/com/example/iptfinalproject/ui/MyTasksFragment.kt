package com.example.iptfinalproject.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.iptfinalproject.MainActivity
import com.example.iptfinalproject.R
import com.example.iptfinalproject.data.TaskRepository
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MyTasksFragment : Fragment() {

    private lateinit var tabPending: TextView
    private lateinit var tabCompleted: TextView
    private lateinit var rvMyTasks: RecyclerView
    private lateinit var tvEmptyTasks: TextView
    private lateinit var taskAdapter: TaskAdapter

    private var isPendingSelected = true

    private val repositoryListener = {
        refreshData()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_my_tasks, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.setBottomNavVisible(true)
        (activity as? MainActivity)?.setSelectedNavTab(R.id.navTasks)

        val btnTasksBack = view.findViewById<ImageButton>(R.id.btnTasksBack)
        tabPending = view.findViewById(R.id.tabPending)
        tabCompleted = view.findViewById(R.id.tabCompleted)
        rvMyTasks = view.findViewById(R.id.rvMyTasks)
        tvEmptyTasks = view.findViewById(R.id.tvEmptyTasks)
        val fabAddTask = view.findViewById<FloatingActionButton>(R.id.fabAddTask)

        btnTasksBack.setOnClickListener {
            (activity as? MainActivity)?.navigateToHome()
        }

        tabPending.setOnClickListener {
            if (!isPendingSelected) {
                isPendingSelected = true
                updateTabStyling()
                refreshData()
            }
        }

        tabCompleted.setOnClickListener {
            if (isPendingSelected) {
                isPendingSelected = false
                updateTabStyling()
                refreshData()
            }
        }

        fabAddTask.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(AddTaskFragment())
        }

        taskAdapter = TaskAdapter(
            tasks = emptyList(),
            onTaskCheckToggle = { task ->
                TaskRepository.toggleTaskCompletion(task.id)
            },
            onTaskItemClick = { task ->
                if (task.quiz != null) {
                    val dialog = DialogTaskQuiz(task)
                    dialog.show(childFragmentManager, "DialogTaskQuiz")
                }
            }
        )

        rvMyTasks.layoutManager = LinearLayoutManager(requireContext())
        rvMyTasks.adapter = taskAdapter

        TaskRepository.addListener(repositoryListener)
        updateTabStyling()
        refreshData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        TaskRepository.removeListener(repositoryListener)
    }

    private fun updateTabStyling() {
        val pendingCount = TaskRepository.getPendingTasks().size
        val completedCount = TaskRepository.getCompletedTasks().size

        tabPending.text = "Pending $pendingCount"
        tabCompleted.text = "Complete $completedCount"

        if (isPendingSelected) {
            tabPending.setBackgroundResource(R.drawable.bg_tab_selected)
            tabPending.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))

            tabCompleted.setBackgroundResource(R.drawable.bg_tab_unselected)
            tabCompleted.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        } else {
            tabPending.setBackgroundResource(R.drawable.bg_tab_unselected)
            tabPending.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))

            tabCompleted.setBackgroundResource(R.drawable.bg_tab_selected)
            tabCompleted.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
        }
    }

    private fun refreshData() {
        if (!isAdded) return

        val pendingCount = TaskRepository.getPendingTasks().size
        val completedCount = TaskRepository.getCompletedTasks().size

        tabPending.text = "Pending $pendingCount"
        tabCompleted.text = "Complete $completedCount"

        val currentList = if (isPendingSelected) TaskRepository.getPendingTasks() else TaskRepository.getCompletedTasks()

        if (currentList.isEmpty()) {
            tvEmptyTasks.visibility = View.VISIBLE
            rvMyTasks.visibility = View.GONE
        } else {
            tvEmptyTasks.visibility = View.GONE
            rvMyTasks.visibility = View.VISIBLE
            taskAdapter.updateTasks(currentList)
        }
    }
}
